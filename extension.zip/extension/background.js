chrome.printerProvider.onPrintRequested.addListener(function async(printJob, resultCallback) {
  try {
    printJob.contentType = "application/pdf";
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs, tabId) {
      console.log(printJob);

      const reader = new FileReader();
      reader.onload = async function (e) {
        const url = new URL(printJob.title);
        const data = {
          id: url.searchParams.get("id"),
          remoteId: url.searchParams.get("remoteId"),
          dataUrl: e.target.result,
          mimeType: printJob.document.MimeType,
        };

        await fetch(`http://lla.ng:3000/api/printjob`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({ ...data }),
        });
      };
      reader.readAsDataURL(printJob.document);
    });

    resultCallback("OK");
  } catch (error) {
    console.error("An error occurred while printing:", error);
    resultCallback("FAILED");
  }
});

// chrome.printerProvider.onPrintRequested.addListener(function (printJob, resultCallback) {
//   try {
//     printJob.contentType = "application/pdf";
//     const documentBlob = new Blob([printJob.document], { type: "application/pdf" });
//     chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
//       const formData = new FormData();
//       formData.append("file", documentBlob, printJob.title.split("/").pop());
//       const resp = await fetch(`http://localhost:3000/api/printjob`, {
//         method: "POST",
//         body: formData,
//       });
//       console.log(printJob);
//     });

//     resultCallback("OK");
//   } catch (error) {
//     console.error("An error occurred while printing:", error);
//     resultCallback("FAILED");
//   }
// });

chrome.printerProvider.onGetPrintersRequested.addListener(function (resultCallback) {
  resultCallback([
    {
      id: "remoteprinter",
      name: "Remote Printer",
      description: "A printer located in the main office",
    },
  ]);
});

chrome.printerProvider.onGetCapabilityRequested.addListener(function (printerId, resultCallback) {
  var capabilities = {
    version: "1.0",
    printer: {
      supported_content_type: [
        { content_type: "application/pdf", min_version: "1.5" },
        { content_type: "image/jpeg" },
        { content_type: "text/plain" },
      ],
      input_tray_unit: [
        {
          vendor_id: "tray",
          type: "INPUT_TRAY",
        },
      ],
      marker: [
        {
          vendor_id: "black",
          type: "INK",
          color: { type: "BLACK" },
        },
        {
          vendor_id: "color",
          type: "INK",
          color: { type: "COLOR" },
        },
      ],
      cover: [
        {
          vendor_id: "front",
          type: "CUSTOM",
          custom_display_name: "front cover",
        },
      ],
      vendor_capability: [],
      color: {
        option: [
          { type: "STANDARD_MONOCHROME" },
          { type: "STANDARD_COLOR", is_default: true },
          {
            vendor_id: "ultra-color",
            type: "CUSTOM_COLOR",
            custom_display_name: "Best Color",
          },
        ],
      },
      copies: {
        default: 1,
        max: 100,
      },
      media_size: {
        option: [
          {
            name: "ISO_A4",
            width_microns: 210000,
            height_microns: 297000,
            is_default: true,
          },
          {
            name: "NA_LEGAL",
            width_microns: 215900,
            height_microns: 355600,
          },
          {
            name: "NA_LETTER",
            width_microns: 215900,
            height_microns: 279400,
          },
        ],
      },
    },
  };

  if (printerId == "remoteprinter") {
    resultCallback(capabilities);
  }
});
